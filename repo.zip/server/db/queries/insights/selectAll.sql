SELECT id, brand, createdAt, text
FROM insights
ORDER BY createdAt DESC;