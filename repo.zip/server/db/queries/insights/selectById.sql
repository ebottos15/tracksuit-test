SELECT id, brand, createdAt, text
FROM insights
WHERE id = ?;