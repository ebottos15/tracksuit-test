INSERT INTO insights (brand, createdAt, text)
VALUES (?, ?, ?);